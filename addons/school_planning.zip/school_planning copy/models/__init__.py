# -*- coding: utf-8 -*-

from . import school_planning
